This is the Hello World example from the git tutorial.
(Changed in the original and pushed to shared)